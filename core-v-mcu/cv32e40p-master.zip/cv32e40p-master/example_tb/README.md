## Example Testbench

This directory supports a minimalist verilog testbench intended to support
sanity level testing of the CV32E40P core.  The complete verification
environment for the CV32E40P is _not_ in this Repository.  Please refer to the
[README](https://github.com/openhwgroup/cv32e40p/edit/master/README.md) at the
top of this repo for more information.
