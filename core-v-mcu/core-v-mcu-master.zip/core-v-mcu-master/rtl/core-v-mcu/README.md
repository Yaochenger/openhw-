# core-v-mcu-soc

The `core-v-mcu-soc` repository contains the structure of the SoC microcontroller
subsystem used in the core-v-mcu which is a derivative of the pulpissimo device from pulp_soc repo
