# AXI Slice

This IP provides AXI slices, i.e. it can be inserted in AXI channels and adds a
FIFO there to ease timing closure.

It uses a generic FIFO which is not part of this IP. For the generic FIFO see
either the PULP common cells or the PULPino RTL sources.
