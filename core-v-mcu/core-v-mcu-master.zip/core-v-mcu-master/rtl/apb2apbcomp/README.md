Converts the APB PULP to the compliant APB. Useful to integrated APB compliant peripherals.
