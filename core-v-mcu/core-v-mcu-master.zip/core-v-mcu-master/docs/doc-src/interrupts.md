# Interrupt Strategy
## Fast Interrupts

## Event Generator


