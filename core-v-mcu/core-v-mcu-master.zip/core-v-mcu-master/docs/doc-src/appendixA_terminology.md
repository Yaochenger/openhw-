# Appendix A Terminology and Conventions

