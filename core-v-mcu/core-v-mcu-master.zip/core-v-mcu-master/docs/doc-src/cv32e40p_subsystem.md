# RISC-V CV32E40P Subsystem
## CV32E40P Description

Short summary and link to Core documentation

## CV32E40P IP Configuration


