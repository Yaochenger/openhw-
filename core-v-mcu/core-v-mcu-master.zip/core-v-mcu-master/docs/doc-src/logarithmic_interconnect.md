# Logarthmic Interconnect

## Features
The Logarthmic Interconnect is a memory-mapped cross-bar providing processor core access to local memory and multiple peripherals.
Chief amoung these peripherals is the micro-DMA (uDMA) engine which control I/O to several IP blocks:
* UART
* I2C
* SPI Master
* Camera IF
* SDIO

## Port-Map

## Theory of Operation
