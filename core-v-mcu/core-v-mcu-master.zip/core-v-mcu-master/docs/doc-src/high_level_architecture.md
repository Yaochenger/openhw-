# High Level Architecture

## Block Diagram

show main subsystems

## Buses

## Memory Concepts

### SRAM

#### Private
#### TCDM

### Logarithmic Interconnect Bus


