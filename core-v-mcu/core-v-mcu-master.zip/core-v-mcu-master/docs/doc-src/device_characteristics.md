# Device Characteristics
## Pinout

## IO State

## Power Characteristics

