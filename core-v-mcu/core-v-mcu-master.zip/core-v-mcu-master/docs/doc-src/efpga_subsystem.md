# eFPGA SubSystem
## Introduction

## Subsystem Architecture

### eFPGA Subsystem Components
### Functional Description
#### Logic Cell
#### Math Units
#### Block RAM
#### FIFO COntroller
#### Clocking

## SoC Interfaces
### Configurable Input/Output Signals
### APB Interface
### TCDM Interface
### Interrupts 

## eFPGA Bitstream Loading
### eFPGA Configuration Control

## eFPGA Subsystem Registers

