# Clock Domains
## eFPGA Clocking Strategy

## PLL and System CLocks
### Introduction
### PLL Description
#### Fractional PLL
#### Clock Divisors

### Clock Gating
### Clock Setup


