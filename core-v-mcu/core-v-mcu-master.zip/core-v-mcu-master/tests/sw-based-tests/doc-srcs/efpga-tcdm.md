## efpga-tcdm

|S.No	| Test Case	| Required	| Status	| Pass/Fail|
| ---   | ---       | ---       | ---       | ---       |
|1	| tcdm0_efpga_ram_write_soc_read_test	    | Yes	    | Done	    | Pass      |
|2	| tcdm1_efpga_ram_write_soc_read_test	| Yes	    | Done	    | Pass      |
|3	| tcdm2_efpga_ram_write_soc_read_test	    | Yes	    | Done	    | Pass      |
|4	| tcdm3_efpga_ram_write_soc_read_test	| Yes	    | Done	    | Pass      |
|5	| tcdm0_soc_write_efpga_ram_read_test	    | Yes	| Done	| Pass|
|6	| tcdm1_soc_write_efpga_ram_read_test	| Yes	| Done	| Pass|
|7	| tcdm2_soc_write_efpga_ram_read_test	| Yes	| Done	| Pass|
|8	| tcdm3_soc_write_efpga_ram_read_test	| Yes	| Done	| Pass|
|9	| tcdm_efpga_ram_soc_read_write_task_test	| Yes	| Done	| Pass|

