## udma-uart1

|S.No | Test Case | Mode | Required | Status | Pass/Fail|
| --- | ---       | ---  | ---      | ---    | --- |
|1 | Set Config | Blocking Operation | Yes | In-Progress | |
|2 | Read char | Blocking Operation | Yes | In-Progress | |
|3 | Write char | Blocking Operation | Yes | In-Progress | |
|4 | Read N char | Blocking Operation | Yes | In-Progress | |
|5 | Write N char | Blocking Operation | Yes | In-Progress | |
|6 | Read through '\n' | Blocking Operation | No | In-Progress | |
|7 | Rx empty | Blocking Operation | Yes | In-Progress | |
|8 | Tx empty | Blocking Operation | Yes | In-Progress | |
|9 | Wait for idle | Blocking Operation | Yes | In-Progress | |
|10 | Read N char | Non-Blocking Operation | No | In-Progress | |
|11 | Write N char | Non-Blocking Operation | No | In-Progress | |
|12 | Read through '\n' | Non-Blocking Operation | No | In-Progress | |