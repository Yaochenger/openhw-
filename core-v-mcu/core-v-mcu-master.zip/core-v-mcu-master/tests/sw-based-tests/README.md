# Documentation

To locally build the documentation run:

```
make doc
```
