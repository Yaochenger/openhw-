#ifndef PROGRAM_FPGA_H
#define PROGRAM_FPGA_H

void programFPGA();

#endif