/*This is a generated file*/

#ifndef __PINMAP_H__
#define __PINMAP_H__


typedef struct {
	short pm[4];
 }gpio_struct_t;

extern gpio_struct_t gpio_map[];
#endif
