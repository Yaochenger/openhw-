/*
 * appconfig.h
 *
 *  Created on: Feb 27, 2021
 *      Author: qlblue
 */

#ifndef SDKCONFIG_
#define SDKCONFIG_

#define	UART_ID_CONSOLE	0	// UART_ID to use as console
#define DEBUG_UART		0	// UART_ID to use for dbg_uart()

#endif /* SDKCONFIG_ */
