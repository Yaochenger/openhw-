# Compile Steps

If you want to build the documentation from source, you can use `make all` to
compile the LaTeX sources. This also takes care of preparing some of the
figures that are generated on-demand.
