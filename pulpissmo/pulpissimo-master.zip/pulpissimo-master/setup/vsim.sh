ROOT=$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")/.." && pwd)
export VSIM_PATH="$ROOT"/sim
